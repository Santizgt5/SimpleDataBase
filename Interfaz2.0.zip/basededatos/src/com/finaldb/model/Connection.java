package com.finaldb.model;

import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleDriver;;

public class Connection {

	public static final String DB_URL = "jdbc:Oracle:thin:@//200.3.193.24:1522/ESTUD";
	public static final String DB_USUARIO = "P09551_1_9";
	public static final String DB_CONTRASENIA = "ChristianSaudade37D1D";

	private String usuario;
	private java.sql.Connection conexion;
	public Connection() {
		conexion = null;
	}

	public void conectarABaseDeDatos() throws SQLException{
		DriverManager.registerDriver(new OracleDriver());
		conexion = DriverManager.getConnection(DB_URL, DB_USUARIO, DB_CONTRASENIA);
	}

	public boolean validarUsuario(String username) throws Exception{
		boolean v = false;
		OracleCallableStatement statement = (OracleCallableStatement) conexion.prepareCall("{? = call pkRegistroN3.verificarCliente(?)}");
		statement.registerOutParameter(1, Types.NUMERIC);
		statement.setString(2, username);
		statement.executeUpdate();
		int retorno = statement.getInt(1);
		if(retorno == 0) {
			usuario = username;
			v = true;
		}
		return v;//(retorno == 0);
	}

	public String getUsuario() {
		return usuario;
	}
	
	public boolean registrarSolicitud(String descripcion, String cliente, String funcionario, String producto, String tipo){
		boolean exito = true;
		try {
			OracleCallableStatement statement = (OracleCallableStatement) conexion.prepareCall("{call pkRegistroN3.registrarSolicitud(?,?,?,?,?,?,?)}");
			System.out.println(statement);
			statement.setString(1, descripcion);
			statement.setString(2, cliente);
			statement.setString(3, funcionario);
			statement.setString(4, producto);
			statement.setInt(5, 0);
			statement.setString(6, "");
			statement.setString(7, tipo);
			statement.executeUpdate();
			statement.close();			
		}
		catch(SQLException e) {
			exito = false;
			System.out.println();
		}
		return exito;
	}
	
	public boolean registrarUsuario(String nombre, String cedula, String telefono, String direccion, Date fecha,String registro) throws Exception {
		boolean exito = false;
		OracleCallableStatement statement = (OracleCallableStatement) conexion.prepareCall("{? = call pkRegistroN3.registrarCliente(?,?,?,?,?,?)}");
		statement.registerOutParameter(1, Types.NUMERIC);
		statement.setString(2, cedula);
		statement.setString(3, nombre);
		statement.setDate(4, fecha);;
		statement.setString(5, direccion);
		statement.setString(6, telefono);
		statement.executeUpdate();			
		int retorno = statement.getInt(1);
		if(retorno == 0) {
			exito = true;		
		}
		return exito;
		
	}
}
