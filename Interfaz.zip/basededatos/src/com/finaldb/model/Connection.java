package com.finaldb.model;

import java.sql.DriverManager;
import java.sql.SQLException;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleDriver;;

public class Connection {

	public static final String DB_URL = "jdbc:Oracle:thin:@//200.3.193.24:1522/ESTUD";
	public static final String DB_USUARIO = "P09551_1_7";
	public static final String DB_CONTRASENIA = "P09551_1_7_20191";

	private String usuario;
	private java.sql.Connection conexion;
	public Connection() {
		conexion = null;
	}

	public void conectarABaseDeDatos() throws SQLException{
		DriverManager.registerDriver(new OracleDriver());
		conexion = DriverManager.getConnection(DB_URL, DB_USUARIO, DB_CONTRASENIA);
	}

	public boolean validarUsuario(String username) throws Exception{
		/**
		OracleCallableStatement statement = (OracleCallableStatement) conexion.prepareCall("{call pkRegistroN3.verificarCliente(?)}");
		statement.setString(1, username);
		statement.executeUpdate();
		int retorno = statement.getInt(1);*/
		usuario = username;
		return false;//(retorno == 0);
	}

	public String getUsuario() {
		return usuario;
	}
	
	public boolean registrarSolicitud(String descripcion, String cliente, String funcionario, String producto){
		boolean exito = true;
		try {
			OracleCallableStatement statement = (OracleCallableStatement) conexion.prepareCall("{call pkRegistroN3.solicitudCrear(?,?,?,?,?,?,?)}");
			statement.setInt(1, 0);
			statement.setString(2, descripcion);
			statement.setString(3, cliente);
			statement.setString(4, funcionario);
			statement.setString(5, producto);
			statement.setInt(6, 0);
			statement.setString(7, "");
			statement.executeUpdate();
			statement.close();			
		}
		catch(SQLException e) {
			exito = false;
		}
		return exito;
	}
	
	public boolean registrarUsuario(String nombre, String cedula, String telefono, String direccion, String fecha,String registro) {
		boolean exito = true;
		try {
			OracleCallableStatement statement = (OracleCallableStatement) conexion.prepareCall("{call pkRegistroN3.solicitudCrear(?,?,?,?,?,?,?)}");
			statement.setString(1, fecha);
			statement.setString(2, nombre);
			statement.setString(3, cedula);
			statement.setString(4, telefono);
			statement.setString(5, direccion);
			statement.setString(6, registro);
			statement.executeUpdate();
			statement.close();			
		}
		catch(SQLException e) {
			exito = false;
		}
		return exito;
	}
}
