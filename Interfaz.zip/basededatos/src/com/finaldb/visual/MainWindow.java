package com.finaldb.visual;

import java.awt.BorderLayout;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.finaldb.model.Connection;

public class MainWindow extends JFrame{

	private static Connection conn;
	private PanelEntrada panelEntrada;
	private PanelOpciones panelOpciones;

	public MainWindow() {

		setLayout(new BorderLayout());
		setTitle("Registro");
		panelEntrada = new PanelEntrada(conn.getUsuario());
		panelOpciones = new PanelOpciones(this);

		add(panelEntrada,BorderLayout.CENTER);
		add(panelOpciones,BorderLayout.SOUTH);
		pack();
		setDefaultCloseOperation(EXIT_ON_CLOSE);


	}

	public static void main(String[] args) {
		String username = "";
		while(true) {
			username = JOptionPane.showInputDialog("Inserte su cedula:");
			if(!username.equals("")) {
				break;
			}
			else {
				JOptionPane.showMessageDialog(null,"Ingrese una cedula.","Error", JOptionPane.ERROR_MESSAGE);
			}
		}

		conn = new Connection();
		MainWindow m = new MainWindow();
		try {
			conn.conectarABaseDeDatos();
			if(conn.validarUsuario(username)) {
				m.setVisible(true);				
			}
			else {
				JOptionPane.showMessageDialog(null,"Debe registrar el usuario.","Error", JOptionPane.ERROR_MESSAGE);
				DialogCrearUsuario d = new DialogCrearUsuario(m);
				d.setVisible(true);
			}
			
		}
		catch(SQLException e) {
			JOptionPane.showMessageDialog(null,"Error al conectar a la base de datos.","Error", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null,"Usuario no existente.","Error", JOptionPane.ERROR_MESSAGE);

		}
	}
	public void registrarSolicitud() {
		String[] datos = panelEntrada.getDatos();
		boolean exito = conn.registrarSolicitud(datos[3], datos[2], "Por confirmar", datos[1]);
		if(exito)
			JOptionPane.showMessageDialog(null,"Solicitud registrada.","Confirmacion", JOptionPane.OK_OPTION);
		else
			JOptionPane.showMessageDialog(null,"Error al registrar la solicitud.","Error", JOptionPane.ERROR_MESSAGE);
	}

	public void registrarUsuario(String cedula, String nombre, String telefono, String direccion, String fecha, DialogCrearUsuario d) {
		boolean exito = conn.registrarUsuario(nombre, cedula, telefono, direccion, fecha, "1");
		if(exito) {
			JOptionPane.showMessageDialog(null,"Usuario registrado.","Confirmacion", JOptionPane.OK_OPTION);
			d.setVisible(false);
			d.dispose();
			this.setVisible(true);
		}
		else {
			JOptionPane.showMessageDialog(null,"Error al registrar usuario.","Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}

