package com.finaldb.visual;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class PanelOpciones extends JPanel implements ActionListener{

	public static final String REGISTRAR = "Registrar";
	
	private MainWindow m;
	
	private JButton registrar;
	
	public PanelOpciones(MainWindow ma) {
		m = ma;
		
		setLayout(new FlowLayout());
		
		registrar = new JButton(REGISTRAR);
		registrar.setActionCommand(REGISTRAR);
		registrar.addActionListener(this);
		
		add(registrar);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals(REGISTRAR)) {
			m.registrarSolicitud();
		}
	}
}
