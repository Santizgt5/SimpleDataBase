package com.finaldb.visual;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class PanelEntrada extends JPanel{

	public static final String[] TIPOS = {"Modificar","Crear","Cancelar"};
	public static final String[] SERVICIOS = {"Voz","Datos","Internet"};

	private JComboBox<String> tipoSolicitud;
	private JComboBox<String> servicio;
	private JLabel nombreUsuario;
	private JTextArea descripcion;

	public PanelEntrada(String username) {

		setLayout(new BorderLayout());

		tipoSolicitud = new JComboBox<String>(TIPOS);
		tipoSolicitud.setBorder(BorderFactory.createTitledBorder("Tipo de solicitud"));
		servicio = new JComboBox<String>(SERVICIOS);
		servicio.setBorder(BorderFactory.createTitledBorder("Servicio"));
		nombreUsuario = new JLabel(username);
		nombreUsuario.setBorder(BorderFactory.createTitledBorder("Nombre de usuario"));
		descripcion = new JTextArea();
		descripcion.setBorder(BorderFactory.createTitledBorder("Descripcion"));
		descripcion.setPreferredSize(new Dimension(490,100));

		JPanel aux = new JPanel(new GridLayout(2,2,6,0));
		aux.setPreferredSize(new Dimension(500,100));
		aux.add(tipoSolicitud);
		aux.add(nombreUsuario);
		aux.add(servicio);

		add(aux,BorderLayout.CENTER);
		add(descripcion, BorderLayout.SOUTH);
	}

	public String[] getDatos() {
		String[] datos = {(String)tipoSolicitud.getSelectedItem(),(String)servicio.getSelectedItem(),
				nombreUsuario.getText(),descripcion.getText()};
		return datos;
	}

}
