package com.finaldb.visual;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JTextField;

public class DialogCrearUsuario extends JDialog implements ActionListener{

	public static final String REGISTRAR = "Registrar";
	
	private JTextField cedula;
	private JTextField nombre;
	private JTextField telefono;
	private JTextField direccion;
	private JTextField fechaNacimiento;

	private JButton registrar;
	
	private MainWindow m;
	
	public DialogCrearUsuario(MainWindow ma) {
		
		m = ma;
		
		setTitle("Registrar usuario");
		setLayout(new GridLayout(3,2,6,0));
		setPreferredSize(new Dimension(400,150));
		
		cedula = new JTextField();
		cedula.setBorder(BorderFactory.createTitledBorder("Cedula"));
		nombre = new JTextField();
		nombre.setBorder(BorderFactory.createTitledBorder("Nombre"));
		telefono = new JTextField();
		telefono.setBorder(BorderFactory.createTitledBorder("Telefono"));
		direccion = new JTextField();
		direccion.setBorder(BorderFactory.createTitledBorder("Direccion"));
		fechaNacimiento = new JTextField("dd/mm/AAAA");
		fechaNacimiento.setBorder(BorderFactory.createTitledBorder("Fecha nacimiento"));
		
		registrar = new JButton(REGISTRAR);
		registrar.setActionCommand(REGISTRAR);
		registrar.addActionListener(this);
		
		add(cedula);
		add(nombre);
		add(telefono);
		add(direccion);
		add(fechaNacimiento);
		add(registrar);
		
		pack();
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	@Override
	public void actionPerformed(ActionEvent a) {
		if(a.getActionCommand().equals(REGISTRAR)) {
			m.registrarUsuario(cedula.getText(),nombre.getText(),telefono.getText(),direccion.getText(),fechaNacimiento.getText(),this);
		}
	}
}
